import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crime-details',
  templateUrl: './crime-details.component.html',
  styleUrls: ['./crime-details.component.css']
})
export class CrimeDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
