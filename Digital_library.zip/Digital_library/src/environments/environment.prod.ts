export const environment = {
  firebase: {
    projectId: 'crud-a996b',
    appId: '1:516613464532:web:fca7d2f848a7eb53d17641',
    databaseURL: 'https://crud-a996b-default-rtdb.firebaseio.com',
    storageBucket: 'crud-a996b.appspot.com',
    apiKey: 'AIzaSyBiSyzrSOlOBUdFVZuDExQQgV7zfLSVteY',
    authDomain: 'crud-a996b.firebaseapp.com',
    messagingSenderId: '516613464532',
    measurementId: 'G-5H0TKG2LB9',
  },
  production: true
};
